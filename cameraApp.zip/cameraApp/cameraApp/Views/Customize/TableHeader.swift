//
//  TableHeader.swift
//  cameraApp
//
//  Created by Pasonatech on 2021/06/03.
//

import UIKit

class TableHeader: UITableViewHeaderFooterView {                                        

    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
